import webbrowser
import time

print('Starting google')
time.sleep(1)
webbrowser.open('https://google.com')

user = input()
if user.lower() == 'l':
  import Launcher
