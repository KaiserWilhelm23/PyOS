print('''

This is working replica of MS-DOS 


     To Veiw the Directory type in: dir 
     you will then get files named ex:
       file_name = ex 
       
       
     the '= ex ' is used to launch a app
     
     this is a read only OS so to download apps you need to install them 
     manually. You also need to delete them manually aswell.
     
Type b to leave this app
       



''')

l = input()
if l.lower() == 'b':
  
  import Launcher
  
