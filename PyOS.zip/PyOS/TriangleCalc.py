
def restart():
  print("--" *10)
  print("What is your biggest number:")
  a = int(input())
  print('What are your other 2 numbers:')
  b = int(input())
  c = int(input())
  uil = [a, b, c, ]
  print("Your Input: ",uil)
  answer1 = b + c
  if answer1 > a:
    print("This is a Triangle!!")
    print("--" *10)
    
  elif answer1 != a:
    print("This is NOT a Triangle!!")
    print("--" *10)
    
  a2 = a**2
  a3 = b**2
  a4 = c**2
  sum = a3 + a4

  if sum < a2:
    print('This is a Obtuse Triangle')
  elif sum > a2:
    print('This is a Acute Triangle')
  elif sum == a2:
    print('This is a Right Triangle')
      
  clear = input()
  if clear.lower() == '':
    
    restart()
  if clear.lower() == 'b':
    
    import Launcher
    
    
    
restart()


