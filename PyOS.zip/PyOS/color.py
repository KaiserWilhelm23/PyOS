import os

os.system("")


class s():
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

class eu():
    
    B = '\033[30m'
    R = '\033[31m'
    G = '\033[32m'
    Y = '\033[33m'
    b = '\033[34m'
    M = '\033[35m'
    C = '\033[36m'
    W = '\033[37m'
    U = '\033[4m'
    R = '\033[0m'
    
