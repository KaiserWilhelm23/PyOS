#this is a website fetcher currently only supports .com websited


import socket

import urllib.request, urllib.parse
import requests
from datetime import datetime
import sys
import time
import certifi
from color import s



host = socket.gethostname()
socket.socket()

def agreement():
  global ag
  ag = input(s.GREEN+'Please agree that this fetcher could fetch a website that you dont know. A unknown site could contain a virus or malware. y/n')
  
agreement()
if ag.lower() == 'y':
  pass
  
else:
  
  print('You did not except the agreement')
  agreement()




print('Version 0.1.0----Supports only .com sites')
print('Rasberry Pi 4 edition')
print('---'*10)


def main():
  url = input('Please type in a website name.')
  start = datetime.now()
  com = '.com'
  h = 'https://'
  


  s = h+url+com

  print('fetching ', url)
  
  print('---'*10)
  animation = "|/-\\"

  for i in range(12):
    time.sleep(0.2)
    sys.stdout.write("\r" + animation[i % len(animation)])
    sys.stdout.flush()
  print('Verifing.....      Requesting ',s)
  
  requests.get(s)


  

    
  def comp():
    
    
      
    print("Fetch Complete")
    print("|=============>| 100%")
    print(s)
   
      
    
    print('---'*20)
    print()
    print('Request made from ', host)
    end_time = datetime.now()
        
    print('Time took to fetch site: {}'.format(end_time - start))
    
      
    f = input('Restart=r Leave=b')
    if f.lower() == 'r':
      
      main()
      
      
    
    
    elif f.lower() =='b':
      import launcher
  
  
  
   
   
    input()
    
    main()
  comp()
  #----------------------------
main()



