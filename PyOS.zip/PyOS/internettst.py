import os

print('Testing Internet Speed')

tst = os.popen('speedtest-cli --simple').readlines()
print(tst)
