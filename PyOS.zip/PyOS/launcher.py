import os
import time
from color import s
from color import eu



def l():
  global c
  print(s.BLUE+'WELCOME TO PyOS ')
  print('--'*20)
  c = input('Open directory or application ')
l()

if c.lower() =='dir':
  print(s.YELLOW+'''
  [ guessing game = g
  
  [ website Fetcher = f
  
  [ pip install = pip    
  
  [ TriangleCalc = tc
  
  [ OS details = osd
  
  [ On Board Calculator = calc
  
  [ PyOS browser = /pyosb

  [ Pynet Controler = pynetr

  [ PyOS cmd = pyos/cmd
  
  ''')
  print('--'*20)
  l()
  


if c.lower() == 'g':
  print('--'*20)
  import guessinggame
  
  
elif c.lower() =='f':
  print('--'*20)
  import websitefetcher
  


  
elif c.lower() == 'tc':
  print('--'*20)
  import TriangleCalc
  
  
  
elif c.lower() == 'osd':
  print('--'*20)
  import osd
  

  
  
elif c.lower() == '/pyosb':
  
  time.sleep(2)
  import PyOSb
  
  
  
  
elif c.lower() == 'rst':
  
  time.sleep(2)
  l()
  
elif c.lower() == 'calc':
  print('--'*20)
  import ffc

elif c.lower() == 'pynet':
  print('--'*20)
  import pynetr





elif c.lower() == 'shutdown':
  print('Shuting Down....')
  time.sleep(4)
  os.system('sudo shutdown -h now')

elif c.lower() == 'reboot':
  print('Rebooting....')
  time.sleep(4)
  os.system('sudo reboot')


elif c.lower() == '-v':
  print('Version 1.0---------Lots of bugs')
  print('--'*20)

  import Launcher


elif c.lower() =='/info':
  f = open('/home/pi/Desktop/PyOS/info/important.txt').read()
  print(f)
  import launcher


elif c.lower() =='cmd':
  user = input('PyOS Terminal  $:')
  a = os.popen(eu.Y+user)
  print(a)
  if a == user+': not found':
    print(eu.R+'Error: 1 Command not found: '+user)
  import launcher


elif c.lower()=='/intertst':
  import internettst
  import launcher
