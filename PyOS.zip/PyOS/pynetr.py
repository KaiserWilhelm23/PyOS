import os
import time

print('Loading Client')
os.system('sudo service apache2 stop')
input('Start Refresher')
global times
times = 0

while True:
    print('---'*10)
    print('Restarting site')
    time.sleep(5)

    os.system('sudo service apache2 restart')
    print('Website Restarted!')
    times = times + 1
    d = times*2.5
    mt = d/60
    print('website restarted: ',times, ' times!')
    
    
    
    
    
    print('---'*10)
