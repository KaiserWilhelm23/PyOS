import os
from color import eu


user = input('PyOS//$:  ')
c=os.popen(user).readlines()
print(eu.Y+'================================')
print(c)
import launcher
